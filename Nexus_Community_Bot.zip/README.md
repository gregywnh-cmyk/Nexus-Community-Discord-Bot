# Nexus Community Bot
1. Put token in .env
2. npm install
3. npm start
